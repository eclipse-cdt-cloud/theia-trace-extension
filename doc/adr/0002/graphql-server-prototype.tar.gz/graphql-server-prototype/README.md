# About these files

Refer to `../../0002-GraphQL.md` to know more about these files and their purpose.
